Setup: Upload and Enable the module.
More info: https://github.com/signalpoint/pathfix/blob/7.x-1.x/README.md

